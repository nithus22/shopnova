"""SHOPNOVA backend application package."""
